// src/config.ts
var config = {
  detector: "classifier",
  mode: "warn",
  contrastRatio: 1.35,
  minFontPx: 2,
  offscreenMarginPx: 32,
  opacityThreshold: 0.05,
  classifierCutoff: 0.42,
  mutationDebounceMs: 300,
  payloadTokenOverlap: 0.6,
  extractorProfiles: ["raw-html", "text-content", "inner-text", "accessibility-tree"]
};

// src/detectors.ts
var instructionPattern = /\b(ignore|disregard|override|follow|reply|output|send|exfiltrate|system prompt|assistant|tool call|CANARY-[A-Z0-9-]+)\b/i;
var selectorOf = (el) => el.id ? `#${CSS.escape(el.id)}` : `${el.tagName.toLowerCase()}${el.className ? "." + String(el.className).trim().split(/\s+/).map(CSS.escape).join(".") : ""}`;
var color = (value) => {
  const m = value.match(/\d+(?:\.\d+)?/g);
  return m ? m.slice(0, 3).map(Number) : [0, 0, 0];
};
var lum = ([r, g, b]) => [r, g, b].map((v) => {
  v /= 255;
  return v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4;
}).reduce((s, v, i) => s + v * [0.2126, 0.7152, 0.0722][i], 0);
var ratio = (a, b) => {
  const [x, y] = [lum(color(a)), lum(color(b))];
  return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05);
};
function visibilityFor(el) {
  const s = getComputedStyle(el);
  const r = el.getBoundingClientRect();
  const reasons = [];
  let vector;
  if (s.display === "none") {
    vector = "display";
    reasons.push("display:none");
  } else if (s.visibility === "hidden") {
    vector = "visibility";
    reasons.push("visibility:hidden");
  } else if (Number(s.opacity) <= config.opacityThreshold) {
    vector = "opacity";
    reasons.push(`opacity ${s.opacity}`);
  } else if (r.right < -config.offscreenMarginPx || r.left > innerWidth + config.offscreenMarginPx || r.bottom < -config.offscreenMarginPx || r.top > innerHeight + config.offscreenMarginPx) {
    vector = "offscreen";
    reasons.push("outside viewport");
  } else if (parseFloat(s.fontSize) < config.minFontPx) {
    vector = "tiny-font";
    reasons.push(`font ${s.fontSize}`);
  } else if (s.clipPath !== "none" || s.position === "absolute" && (s.clip === "rect(0px, 0px, 0px, 0px)" || r.width <= 1 || r.height <= 1)) {
    vector = "clip";
    reasons.push("clipped");
  } else if (ratio(s.color, s.backgroundColor === "rgba(0, 0, 0, 0)" ? "#fff" : s.backgroundColor) < config.contrastRatio) {
    vector = "low-contrast";
    reasons.push("low effective contrast");
  }
  return { humanVisible: !vector, agentVisible: true, vector, reasons };
}
function walk(root, classifier) {
  const findings2 = [];
  const inspect = (el, text, vectorOverride) => {
    const clean = text.replace(/[\u200B-\u200F\u2060\u{E0000}-\u{E007F}]/gu, "");
    const visibility = visibilityFor(el);
    const vector = vectorOverride || visibility.vector;
    const hidden = !!vector || clean !== text;
    const score = instructionPattern.test(clean) ? 0.9 : 0.15;
    if (hidden && (!classifier || score >= config.classifierCutoff)) findings2.push({ selector: selectorOf(el), text: clean.trim().slice(0, 500), vector: vector || "unicode", reasons: [...visibility.reasons, clean !== text ? "zero-width or Unicode tag characters" : "", instructionPattern.test(clean) ? "instruction-like" : ""].filter(Boolean), score, detector: classifier ? "classifier" : "rules", sanitized: false });
  };
  root.querySelectorAll("*").forEach((el) => {
    const ownText = [...el.childNodes].filter((n) => n.nodeType === Node.TEXT_NODE).map((n) => n.textContent || "").join(" ").trim();
    if (ownText) inspect(el, ownText);
    for (const attr of ["alt", "aria-label", "title"]) {
      const value = el.getAttribute(attr);
      if (value && instructionPattern.test(value)) inspect(el, value, "attribute");
    }
    const pseudo = [getComputedStyle(el, "::before").content, getComputedStyle(el, "::after").content].filter((x) => x && x !== "none" && x !== "normal").join(" ");
    if (pseudo && instructionPattern.test(pseudo)) inspect(el, pseudo.replace(/^['"]|['"]$/g, ""), "pseudo");
  });
  const comments = document.createTreeWalker(root, NodeFilter.SHOW_COMMENT);
  for (let node = comments.nextNode(); node; node = comments.nextNode()) if (instructionPattern.test(node.textContent || "")) findings2.push({ selector: "<!--comment-->", text: (node.textContent || "").trim(), vector: "comment", reasons: ["HTML comment", "instruction-like"], score: 0.9, detector: classifier ? "classifier" : "rules", sanitized: false });
  return findings2;
}
var registry = {
  rules: { id: "rules", detect: (root) => walk(root, false) },
  classifier: { id: "classifier", detect: (root) => walk(root, true) },
  "llm-judge-skeleton": { id: "llm-judge-skeleton", detect: () => [] }
};

// src/content.ts
var findings = [];
function apply() {
  findings = registry[config.detector].detect(document);
  if (config.mode === "sanitize") for (const finding of findings) {
    const el = document.querySelector(finding.selector);
    if (el) {
      el.dataset.parallaxSanitized = "true";
      el.style.setProperty("display", "none", "important");
      finding.sanitized = true;
    }
  }
  chrome.runtime.sendMessage({ type: "parallax-report", report: { url: location.href, scannedAt: (/* @__PURE__ */ new Date()).toISOString(), findings } }).catch(() => void 0);
  document.querySelectorAll("[data-parallax-flag]").forEach((e) => e.remove());
  for (const f of findings) {
    const el = document.querySelector(f.selector);
    if (el && f.vector !== "comment") {
      el.dataset.parallaxFlag = "true";
      el.title = `Parallax: ${f.reasons.join(", ")}`;
      el.style.outline = "2px solid #e5484d";
    }
  }
}
var timer;
new MutationObserver(() => {
  clearTimeout(timer);
  timer = window.setTimeout(apply, config.mutationDebounceMs);
}).observe(document.documentElement, { subtree: true, childList: true, characterData: true, attributes: true });
apply();
chrome.runtime.onMessage.addListener((msg, _, reply) => {
  if (msg.type === "parallax-get-report") reply({ findings });
});
